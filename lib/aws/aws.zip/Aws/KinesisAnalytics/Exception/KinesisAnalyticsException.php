<?php
namespace Aws\KinesisAnalytics\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **Amazon Kinesis Analytics** service.
 */
class KinesisAnalyticsException extends AwsException {}
